public class Sample {
    private int x;
    private int y;

    public Sample(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "Sample{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}
