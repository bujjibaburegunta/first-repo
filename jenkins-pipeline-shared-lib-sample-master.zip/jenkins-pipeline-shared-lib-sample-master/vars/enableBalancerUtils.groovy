#!/usr/bin/env groovy

def call(body) {
    echo "Enable balancer"
    return this
}
